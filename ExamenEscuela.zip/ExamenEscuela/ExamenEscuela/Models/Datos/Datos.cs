﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ExamenEscuela.Models.Entidades;

namespace ExamenEscuela.Models.Datos
{
    public class Datos
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString);

        public List<Alumno> VerAlumnos()
        {



            List<Alumno> ls = new List<Alumno>();

            SqlCommand cmd = new SqlCommand("VERALUMNO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                Alumno a = new Alumno();

                a.IdAlumno = Convert.ToInt32(dr["IdAlumno"]);
                a.NombreCompleto = dr["NombreCompleto"].ToString();
                a.FechaNacimiento = Convert.ToDateTime(dr["FechaNacimiento"]);
                a.Edad = Convert.ToInt32(dr["Edad"]);
                a.Matricula = dr["Matricula"].ToString();
                a.CorreoElectronico = dr["CorreoElectronico"].ToString();
                a.Genero = Convert.ToBoolean(dr["Genero"]);
                a.Carrera = dr["Carrera"].ToString();

                ls.Add(a);
            }
            return ls;
        }

        public List<Materia> VerMaterias()
        {



            List<Materia> ls = new List<Materia>();

            SqlCommand cmd = new SqlCommand("VERMATERIA", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                Materia m = new Materia();

                m.IdMateria = Convert.ToInt32(dr["IdMateria"]);
                m.NombreMateria = dr["NombreMateria"].ToString();
                m.DescrMateria = dr["DescrMateria"].ToString();
                m.NoCreditos = dr["NoCreditos"].ToString();

                ls.Add(m);
            }
            return ls;
        }


        public Materia ObtenerIDMateria(int id)
        {
            SqlCommand cmd = new SqlCommand("VERMATERIAxID", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            DataRow dr = dt.Rows[0];

            Materia m = new Materia();

            m.IdMateria = Convert.ToInt32(dr["IdMateria"]);
            m.NombreMateria = dr["NombreMateria"].ToString();
            m.DescrMateria = dr["DescrMateria"].ToString();
            m.NoCreditos = dr["NoCreditos"].ToString();

            return m;
        }
        public Alumno ObtenerIDAlumno(int id)
        {
            SqlCommand cmd = new SqlCommand("VERALUMNOxID", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            DataRow dr = dt.Rows[0];

            Alumno a = new Alumno();

            a.IdAlumno = Convert.ToInt32(dr["IdAlumno"]);
            a.NombreCompleto = dr["NombreCompleto"].ToString();
            a.FechaNacimiento = Convert.ToDateTime(dr["FechaNacimiento"]);
            a.Edad = Convert.ToInt32(dr["Edad"]);
            a.Matricula = dr["Matricula"].ToString();
            a.CorreoElectronico = dr["CorreoElectronico"].ToString();
            a.Genero = Convert.ToBoolean(dr["Genero"]);
            a.Carrera = dr["Carrera"].ToString();


            return a;
        }


        public void AgregarAlumnos(Alumno a)
        {


            SqlCommand cmd = new SqlCommand("AgregarAlumno", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@NombreCompleto", a.NombreCompleto);
            cmd.Parameters.AddWithValue("@FechaNacimiento", a.FechaNacimiento);
            cmd.Parameters.AddWithValue("@Matricula", a.Matricula);
            cmd.Parameters.AddWithValue("@CorreoElectronico", a.CorreoElectronico);
            cmd.Parameters.AddWithValue("@Genero", a.Genero);
            cmd.Parameters.AddWithValue("@Carrera", a.Carrera);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }



        public void AgregarMateria(Materia m)
        {


            SqlCommand cmd = new SqlCommand("AgregarMateria", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@NombreMateria", m.NombreMateria);
            cmd.Parameters.AddWithValue("@DescrMateria", m.DescrMateria);
            cmd.Parameters.AddWithValue("@NoCreditos", m.NoCreditos);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

        public void EditarAlumno(Alumno a)
        {
            SqlCommand cmd = new SqlCommand("EDITARALUMNO", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@NombreCompleto", a.NombreCompleto);
            cmd.Parameters.AddWithValue("@FechaNacimiento", a.FechaNacimiento);
            cmd.Parameters.AddWithValue("@Edad", a.Edad);
            cmd.Parameters.AddWithValue("@Matricula", a.Matricula);
            cmd.Parameters.AddWithValue("@CorreoElectronico", a.CorreoElectronico);
            cmd.Parameters.AddWithValue("@Genero", a.Genero);
            cmd.Parameters.AddWithValue("@Carrera", a.Carrera);
            cmd.Parameters.AddWithValue("@Id", a.IdAlumno);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

        public void EditarMateria(Materia m)
        {
            SqlCommand cmd = new SqlCommand("EDITARMATERIAS", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@NombreMateria", m.NombreMateria);
            cmd.Parameters.AddWithValue("@DescrMateria", m.DescrMateria);
            cmd.Parameters.AddWithValue("@NoCreditos", m.NoCreditos);
            cmd.Parameters.AddWithValue("@ID", m.IdMateria);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

        public void BorrarAlumno(Alumno a)
        {
            SqlCommand cmd = new SqlCommand("BORRARaLUMNOS", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", a.IdAlumno);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

        public void BorrarMateria(Materia m)
        {
            SqlCommand cmd = new SqlCommand("BORRARMATERIA", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", m.IdMateria);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

        public List<Alumno> ObtenerDT(int id)
        {
            SqlCommand cmd = new SqlCommand("ALUMNOMATERIASID", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@IDAlumno", id);

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();

            da.Fill(dt);

            List<Alumno> ls = new List<Alumno>();
            if (dt.Rows.Count > 0)
            {
               

                foreach (DataRow dr in dt.Rows)
                {
                    Alumno a = new Alumno();

                    Materia m = new Materia();
                    AlumnoMateria am = new AlumnoMateria();
                    a.IdAlumno = Convert.ToInt32(dr["IdAlumno"]);
                    a.NombreCompleto = dr["NombreCompleto"].ToString();
                    a.FechaNacimiento = Convert.ToDateTime(dr["FechaNacimiento"]);
                    a.Edad = Convert.ToInt32(dr["Edad"]);
                    a.Matricula = dr["Matricula"].ToString();
                    a.CorreoElectronico = dr["CorreoElectronico"].ToString();
                    a.Genero = Convert.ToBoolean(dr["Genero"]);
                    a.Carrera = dr["Carrera"].ToString();

                    am.Id = Convert.ToInt32(dr["Id"]);
                    
                    m.IdMateria = Convert.ToInt32(dr["IdMateria"]);
                    m.NombreMateria = dr["NombreMateria"].ToString();
                    //m.DescrMateria = dr["DescrMateria"].ToString();
                    //m.NoCreditos = dr["NoCreditos"].ToString();
                    a.EntMateria = m;
                    a.EntAlumMat = am;

                    ls.Add(a);
                }

            }
            return ls;
        }


        public void BorrarAluMate(AlumnoMateria am)
        {
            SqlCommand cmd = new SqlCommand("BORRARALUMNOMATERIA", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", am.Id);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }


        public void AgregarMatAlumno(Alumno a)
        {


            SqlCommand cmd = new SqlCommand("AgregarMateriaAlumno", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@IdAlum", a.IdAlumno);
            cmd.Parameters.AddWithValue("@IdMateria", a.IdMate);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

    }
}