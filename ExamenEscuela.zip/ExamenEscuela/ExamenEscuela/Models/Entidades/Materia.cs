﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamenEscuela.Models.Entidades
{
    public class Materia
    {
        public int IdMateria { get; set; }
        public string NombreMateria { get; set; }
        public string DescrMateria { get; set; }
        public string NoCreditos { get; set; }
     
    }
}