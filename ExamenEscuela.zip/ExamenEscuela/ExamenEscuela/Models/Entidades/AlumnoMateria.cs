﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamenEscuela.Models.Entidades
{
    public class AlumnoMateria
    {
        public int Id { get; set; }
        public int IdAlum { get; set; }
        public int IdMaterias { get; set; }
        public Alumno Alumno { get; set; }
        public Materia Materia { get; set; }
    }
}