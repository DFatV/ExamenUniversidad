﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamenEscuela.Models.Entidades
{
    public class Alumno
    {
        public int IdAlumno { get; set; }
        public string NombreCompleto { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public int Edad { get; set; }
        public string Matricula { get; set; }
        public string CorreoElectronico { get; set; }
        public bool Genero { get; set; }
        public string Carrera { get; set; }
        public int IdMate { get; set; }
        public Materia EntMateria{ get; set; }
        public AlumnoMateria EntAlumMat { get; set; }
    }
}