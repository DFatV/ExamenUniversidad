﻿using ExamenEscuela.Models.Datos;
using ExamenEscuela.Models.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExamenEscuela.Controllers
{
    public class HomeController : Controller
    {
        Datos d = new Datos();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult visualizarAlumnos()
        {
            try
            {
                List<Alumno> ls = d.VerAlumnos();


                return View(ls);

            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return View(new List<Alumno>());
            }
        }

        public ActionResult visualizarMaterias()
        {
            try
            {
                List<Materia> ls = d.VerMaterias();


                return View(ls);

            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return View(new List<Materia>());
            }
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Alumno a)
        {
            try
            {
                d.AgregarAlumnos(a);
                return View("visualizarAlumnos", d.VerAlumnos());
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return View("Create");
            }
        }
        public ActionResult CreateMVista()
        {
            return View();
        }
        public ActionResult CreateMateria(Materia m)
        {
            try
            {
                d.AgregarMateria(m);
                return View("visualizarMaterias", d.VerMaterias());
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return View("CreateMVista");
            }
        }


        public ActionResult Edit(int id)
        {
            try
            {
                Alumno a = d.ObtenerIDAlumno(id);
                return View(a);
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("visualizarAlumnos");
            }
        }
        public ActionResult EditarAlum(Alumno a)
        {
            try
            {
                d.EditarAlumno(a);
                TempData["msj"] = "Se edito a " + a.NombreCompleto;
                return RedirectToAction("visualizarAlumnos");
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("Edit", new { id = a.IdAlumno });
            }
        }

        public ActionResult EditM(int id)
        {
            try
            {
                Materia m = d.ObtenerIDMateria(id);
                return View(m);
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("visualizarMaterias");
            }
        }
        public ActionResult EditarMateria(Materia m)
        {
            try
            {
                d.EditarMateria(m);
                TempData["msj"] = "Se edito " + m.NombreMateria;
                return RedirectToAction("visualizarMaterias");
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("EditM", new { id = m.IdMateria });
            }
        }
        
        public ActionResult Delete(int id)
        {
            try
            {
                Alumno a = d.ObtenerIDAlumno(id);
                return View(a);
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("visualizarAlumnos");
            }
        }
        public ActionResult DeleteAlumno(Alumno a)
        {
            try
            {
                d.BorrarAlumno(a);
                TempData["msj"] = "Se borro a " + a.NombreCompleto;
                return RedirectToAction("visualizarAlumnos");
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("Delete", new { id = a.IdAlumno });
            }
        }


        public ActionResult DeleteM(int id)
        {
            try
            {
                Materia m = d.ObtenerIDMateria(id);
                return View(m);
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("visualizarMaterias");
            }
        }
        public ActionResult DeleteMaterias(Materia m)
        {
            try
            {
                d.BorrarMateria(m);
                TempData["msj"] = "Se borro " + m.NombreMateria;
                return RedirectToAction("visualizarMaterias");
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("DeleteM", new { id = m.IdMateria });
            }
        }

        public ActionResult AlumnosMaterias(int id)
        {
            try
            {
                return View(d.ObtenerDT(id));
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                List<Alumno> ls = new List<Alumno>();
                return View(ls);
            }
        }

        public ActionResult DeleteMateriasAlum(AlumnoMateria am)
        {
            try
            {
                d.BorrarAluMate(am);
                TempData["msj"] = "Se borro ";
                return RedirectToAction("AlumnosMaterias",new { id=am.IdAlum });
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("AlumnosMaterias", new { id = am.IdAlum });
            }
        }

        [HttpGet]
        public ActionResult AgregarMatCAlumn(int id)
        {
            try
            {
                Alumno a = d.ObtenerIDAlumno(id);

                List<Materia> ls = d.VerMaterias();
                ViewBag.IdMate = new SelectList(ls, "IdMateria", "NombreMateria");

                return View(a);
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;
                return RedirectToAction("AlumnosMaterias");
            }
        }


        [HttpPost]
        public ActionResult AgregarMatCAlumn(Alumno a)
        {
            try
            {
                d.AgregarMatAlumno(a);
                return View("visualizarAlumnos", d.VerAlumnos());
            }
            catch (Exception ex)
            {
                TempData["error"] = ex.Message;


                List<Materia> ls = d.VerMaterias();
                ViewBag.IdMate = new SelectList(ls, "IdMateria", "NombreMateria");
                return View("AgregarMatCAlumn");
            }
        }



    }
}